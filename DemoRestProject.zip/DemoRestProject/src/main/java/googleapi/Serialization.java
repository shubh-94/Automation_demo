package googleapi;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.Addplace;
import pojo.Location;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.List;

public class Serialization {

	public static void main(String[] args)
	{
		RestAssured.baseURI="https://rahulshettyacademy.com";
		
		Addplace p =new Addplace();
		p.setAccuracy(50);
		p.setAddress("29,Side lAyout,Florida");
		p.setLanguage("English");
		p.setPhone_number("+1(212)1232141");
		p.setWebsite("https://rahulshettyacademy.com");
		p.setName("Roshan Villa");
		
		List<String> mylist= new ArrayList<String>();
		mylist.add("Shoe village");
		mylist.add("Firm");
		
		p.setTypes(mylist);
		
		
		Location locn=new Location();
locn.setLat(-32.4353);
locn.setLng(33.4322);

p.setLocation(locn);
		
RequestSpecification req= new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").addQueryParam("key", "qaclick123")
.setContentType(ContentType.JSON).build();
		
ResponseSpecification resp= new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();

RequestSpecification response=given().spec(req).body(p);
		
		Response respon=response.when().post("/maps/api/place/add/json")
		.then().spec(resp).extract().response();
		
		String responsestr=respon.asString();
		System.out.println(responsestr);
		
		
	}
}

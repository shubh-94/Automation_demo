package googleapi;

import io.restassured.RestAssured;
import pojo.Addplace;
import pojo.Location;

import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.List;

public class SpecBuildertest {

	public static void main(String[] args)
	{
		RestAssured.baseURI="https://rahulshettyacademy.com";
		
		Addplace p =new Addplace();
		p.setAccuracy(50);
		p.setAddress("29,Side lAyout,Florida");
		p.setLanguage("English");
		p.setPhone_number("+1(212)1232141");
		p.setWebsite("https://rahulshettyacademy.com");
		p.setName("Roshan Villa");
		
		List<String> mylist= new ArrayList<String>();
		mylist.add("Shoe village");
		mylist.add("Firm");
		
		p.setTypes(mylist);
		
		
		Location locn=new Location();
locn.setLat(-32.4353);
locn.setLng(33.4322);
p.setLocation(locn);
		
		
		String response=given().log().all().contentType("application/json").queryParam("key", "qaclick123").body(p)
		.when().post("/maps/api/place/add/json")
		.then().assertThat().statusCode(200).extract().response().asString();
		
		System.out.println(response);
		
		
	}
}

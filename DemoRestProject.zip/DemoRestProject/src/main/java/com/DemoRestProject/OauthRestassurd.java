package com.DemoRestProject;
import static io.restassured.RestAssured.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fasterxml.jackson.core.JsonParseException;

import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;
import junit.framework.Assert;
import pojo.Api;
import pojo.Getcourse;
import pojo.Webautomation;
public class OauthRestassurd {

	public static void main(String[] args) throws InterruptedException {
		
		
		/*	System.setProperty("webdriver.chrome.driver", "C://Users//SAKSOFT071.SAKSOFT071PDC//Downloads//chromedriver_win32 (5)//chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com/signin/oauth/identifier?scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&auth_url=https%3A%2F%2Faccounts.google.com%2Fo%2Foauth2%2Fv2%2Fauth&client_id=692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com&response_type=code&redirect_uri=https%3A%2F%2Frahulshettyacademy.com%2FgetCourse.php&o2v=2&as=s6eZxpYcjWGsoKXKIA-JwQ&flowName=GeneralOAuthFlow");
		
	driver.findElement(By.id("identifierId")).sendKeys("shubhsawant94");
		driver.findElement(By.id("identifierId")).sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[type='email']")).sendKeys("shubhsawant94");
		driver.findElement(By.cssSelector("input[type='email']")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input[type='password']")).sendKeys("Ramnath@123");
		driver.findElement(By.cssSelector("[input[type='password]")).sendKeys(Keys.ENTER);
		Thread.sleep(4000);*/
		String url= "https://rahulshettyacademy.com/getCourse.php?code=4%2F0AF1KSdqqBbRkDgqElqpOdbgWohZzTd4CgD9csDcOgk5leArznJuh7FTsJqjn8MOPV-1S-HmedrfNlkU-46d4qM&scope=email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+openid&authuser=0&prompt=none";
		//String url=driver.getCurrentUrl();
		
		String partialcode=url.split("code=")[1];
		String code=partialcode.split("&scope")[0];
		System.out.println(code);
		
		
		String[] coursetitles={"Selenium Webdriver Java","Cypress","Protractor","Appium"};
		
		
		String accesstokenResponse=	given().urlEncodingEnabled(false).queryParam("code", code)
		.queryParam("client_id", "692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com")
		.queryParam("client_secret", "erZOWM9g3UtwNRj340YYaK_W")
		.queryParam("redirect_uri", "https://rahulshettyacademy.com/getCourse.php")
		.queryParam("grant_type", "authorization_code")
		.when().log().all()
		.post("https://www.googleapis.com/oauth2/v4/token").asString();
		
		System.out.println(accesstokenResponse);
		
		JsonPath js=new JsonPath(accesstokenResponse);
		String accesstoken=js.getString("access_token");
		
		System.out.println(accesstoken);
		
		Getcourse gc =given().contentType("application/json").queryParam("access_token", accesstoken)
		.expect().defaultParser(Parser.JSON)
		.when()
		.get("https://rahulshettyacademy.com/getCourse.php").as(Getcourse.class);
		
	//	System.out.println("Response is :" +response);
		System.out.println(gc.getLinkedIn());
		System.out.println(gc.getInstructor());
		System.out.println(gc.getCourses().getApi().get(1).getCourseTitle());
		
		List<Api> api = gc.getCourses().getApi();
		for(int i=0;i<api.size();i++)
		{
			if(api.get(i).getCourseTitle().equalsIgnoreCase("Rest Assured Automation using Java"))
			{
				System.out.println(api.get(i).getPrice());
			}
		}
		
		
		ArrayList <String> a = new ArrayList<String>();
		
		List<Webautomation> w = gc.getCourses().getWebAutomation();
		for(int j=0;j<w.size();j++)
		{
			a.add(w.get(j).getCourseTitle());
		}

		List<String> expectedList = Arrays.asList(coursetitles);
		
		Assert.assertTrue(a.equals(expectedList));
	}
	
}

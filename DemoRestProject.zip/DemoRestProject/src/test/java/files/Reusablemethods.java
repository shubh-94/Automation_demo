package files;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class Reusablemethods {

	
	//to reuse this method
	public static JsonPath rawToJson(String resp)
	{
		JsonPath js1 =new JsonPath(resp);
		return js1;
	}

	
}

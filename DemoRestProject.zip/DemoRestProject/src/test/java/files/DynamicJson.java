package files;


import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import files.Payload;
import files.Reusablemethods;

public class DynamicJson {

	@Test(dataProvider="Books")
	public void addBook(String isbn,String aisle)
	{
	RestAssured.baseURI="http://216.10.245.166";
	
	Response resp=given().log().all().header("Content-Type","application/json")
		.body(Payload.addBook(isbn,aisle))
		.when().post("/Library/Addbook.php")
		.then().log().all().assertThat().statusCode(200)
		.extract().response();
	
	JsonPath js=Reusablemethods.rawToJson(resp.asString());
	String bookID=js.get("ID");
	
	System.out.println(bookID);
	}
	
	@DataProvider(name="Books")
	public Object[][] getData()
	{
		return new Object[][] {{"abcz","121"},{"xyzq","229"},{"pqrs","321"}};
	}
	
}

package Streamsexercise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


import org.testng.Assert;
import org.testng.annotations.Test;




public class test1 {

	//Count the no of names starting with alphabet A in list
	@Test
	public void regular()
	{
		ArrayList<String> names = new ArrayList<String>();
		names.add("Parantak");
		names.add("Aishwarya");
		names.add("Rahul");
		names.add("Abhijit");
		names.add("Ankush");
		int count=0;
		
		for(int i=0;i<names.size();i++)
		{
			String allname=names.get(i);		
			if(allname.startsWith("A"))
			{
				count++;
			}
		
	}
		System.out.println(count);
}
	
	@Test
	public void streamFilter()
	{
		ArrayList<String> names = new ArrayList<String>();
		names.add("Parantak");
		names.add("Aishwarya");
		names.add("Rahul");
		names.add("Abhijit");
		names.add("Ankush");
		
		//we can create Stream
		//how to use filter in stream API
		//
		
		Long c=names.stream().filter(a->a.startsWith("A")).count();  //It will check parallely -> streams
		System.out.println(c);
		
		
		long d=Stream.of("Abhijit","Shreya","Ashlesha","Amit","Joseph").filter(s->
				{
					s.startsWith("A");
					return true;
				}).count();
		System.out.println(d);
	
	//Print all the names of Arraylist
		
		//names.stream().filter(s->s.length()>6).forEach(s->System.out.println(s));
		names.stream().filter(s->s.length()>6).limit(1).forEach(s->System.out.println(s));
	
	
	
	}

	
	@Test
	public void streamMap()
	{
		
		ArrayList<String> names = new ArrayList<String>();
		names.add("Adam");
		names.add("Shereyash");
		names.add("Rahul");
		names.add("Abhijit");
		names.add("Ankush");
		
		//print names which have last letter a with uppercase
		Stream.of("Abhijit","Shreya","Ashlesha","Amit","Joseph").filter(s->s.endsWith("a"))
		.map(s->s.toUpperCase()).forEach(s->System.out.println(s));
	
	
	//print names which have first letter as a with uppercase and sorted
	
	//convert array into arraylist
	List<String>names1=Arrays.asList("Adam","Shreyash","Anup","Ashok","Joy");
	names1.stream().filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.println(s));
	
	//Merging two different list
	Stream<String>newStream=Stream.concat(names.stream(),names1.stream());
	//newStream.sorted().forEach(s->System.out.println(s));
	
	//Match 
	boolean flag=newStream.anyMatch(s->s.equalsIgnoreCase("Adam"));
	System.out.println(flag);
	Assert.assertTrue(flag);
	
	}

	
	@Test
	public void streamCollect()  //collect method-->use to collect your results and convert it back into any list
	{
		
		List<String> ln=Stream.of("Abhijit","Shreya","Amrita","Amit","Joseph").filter(s->s.endsWith("a")).map(s->s.toUpperCase())
		.collect(Collectors.toList());
		
		System.out.println(ln.get(0));
		//Print unique number from this array
		//sort the array and give me the 3rd index - 1,2,3,4,5,9
		List<Integer>values=Arrays.asList(2,3,2,1,1,1,5,9,4);
		values.stream().distinct().forEach(s->System.out.println(s));
		List<Integer>lint=values.stream().distinct().sorted().collect(Collectors.toList());
		System.out.println(lint.get(2));
	}
	


}
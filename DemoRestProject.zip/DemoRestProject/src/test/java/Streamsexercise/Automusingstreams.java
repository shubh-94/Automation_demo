package Streamsexercise;

import java.util.List;
import java.util.stream.Collectors;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.*;

import junit.framework.Assert;

public class Automusingstreams {

public static void main(String[] args) throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "E:\\chromedriver_win32\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	
	driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
	/*driver.findElement(By.xpath("//a[contains(text(),'Top Deals')]")).click();
	Thread.sleep(3000);*/
	
	driver.findElement(By.xpath("//tr/th[1]")).click();
//	driver.findElement(By.xpath("//tr/th[1]")).click();
	//capture all webelements into list
	List<WebElement>elementlist=driver.findElements(By.xpath("//tr/td[1]"));
	
	//capture text of all webelements into new original list
	List<String> originallist=elementlist.stream().map(s->s.getText()).collect(Collectors.toList());
	
	//sort on the original list
	List<String>sortedlist=originallist.stream().sorted().collect(Collectors.toList());
	
	//Compare the list
	
	Assert.assertTrue(originallist.equals(sortedlist));
	List<String> price;
	//Get price of each vegetable
	do
	{
		List<WebElement>rows=driver.findElements(By.xpath("//tr/td[1]"));
		price= rows.stream().filter(s->s.getText().contains("Rice"))
	.map(s->getPrice(s)).collect(Collectors.toList());
	price.forEach(a->System.out.println(a));
	
	if(price.size()<1)
	{
		driver.findElement(By.cssSelector("[aria-label=\"Next\"]")).click();
	}
		}while(price.size()<1);
	
	
	//To verify filter option or search option using java streams
	driver.findElement(By.id("search-field")).sendKeys("Rice");
	List<WebElement>veggies=driver.findElements(By.xpath("//tr/td[1]"));
	List<WebElement> filteredlist=veggies.stream().filter(veggie->veggie.getText().contains("Rice"))
	.collect(Collectors.toList());
	
	Assert.assertEquals(veggies.size(), filteredlist.size());
}

	private static String getPrice(WebElement s) {

		String pricevalue=	s.findElement(By.xpath("following-sibling::td[1]")).getText();
		return pricevalue;
	
}



}
